﻿namespace HR.Tools
{
    public class ToolsConsts
    {
        public const string LocalizationSourceName = "Tools";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
