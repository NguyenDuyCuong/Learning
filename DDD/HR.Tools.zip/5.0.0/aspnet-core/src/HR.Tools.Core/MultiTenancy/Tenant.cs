﻿using Abp.MultiTenancy;
using HR.Tools.Authorization.Users;

namespace HR.Tools.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}
