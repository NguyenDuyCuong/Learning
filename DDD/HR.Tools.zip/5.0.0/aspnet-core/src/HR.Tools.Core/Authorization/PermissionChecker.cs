﻿using Abp.Authorization;
using HR.Tools.Authorization.Roles;
using HR.Tools.Authorization.Users;

namespace HR.Tools.Authorization
{
    public class PermissionChecker : PermissionChecker<Role, User>
    {
        public PermissionChecker(UserManager userManager)
            : base(userManager)
        {
        }
    }
}
