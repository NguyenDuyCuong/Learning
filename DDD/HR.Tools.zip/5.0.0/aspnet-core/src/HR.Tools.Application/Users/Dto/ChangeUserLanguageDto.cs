using System.ComponentModel.DataAnnotations;

namespace HR.Tools.Users.Dto
{
    public class ChangeUserLanguageDto
    {
        [Required]
        public string LanguageName { get; set; }
    }
}