﻿using System.Threading.Tasks;
using HR.Tools.Configuration.Dto;

namespace HR.Tools.Configuration
{
    public interface IConfigurationAppService
    {
        Task ChangeUiTheme(ChangeUiThemeInput input);
    }
}
