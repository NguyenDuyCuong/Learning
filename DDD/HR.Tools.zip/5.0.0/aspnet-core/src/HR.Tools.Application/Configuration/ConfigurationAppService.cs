﻿using System.Threading.Tasks;
using Abp.Authorization;
using Abp.Runtime.Session;
using HR.Tools.Configuration.Dto;

namespace HR.Tools.Configuration
{
    [AbpAuthorize]
    public class ConfigurationAppService : ToolsAppServiceBase, IConfigurationAppService
    {
        public async Task ChangeUiTheme(ChangeUiThemeInput input)
        {
            await SettingManager.ChangeSettingForUserAsync(AbpSession.ToUserIdentifier(), AppSettingNames.UiTheme, input.Theme);
        }
    }
}
