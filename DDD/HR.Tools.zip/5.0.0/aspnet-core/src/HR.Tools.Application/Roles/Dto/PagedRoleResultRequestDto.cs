﻿using Abp.Application.Services.Dto;

namespace HR.Tools.Roles.Dto
{
    public class PagedRoleResultRequestDto : PagedResultRequestDto
    {
        public string Keyword { get; set; }
    }
}

