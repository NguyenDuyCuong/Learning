﻿// ***********************************************************************
// Assembly         : FrederickNguyen.DomainCore
// Author           : thangnd
// Created          : 06-15-2018
//
// Last Modified By : thangnd
// Last Modified On : 06-15-2018
// ***********************************************************************
// <copyright file="IAggregateRoot.cs" company="FrederickNguyen.DomainCore">
//     Copyright (c) by adguard. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System;

namespace FrederickNguyen.DomainCore.Models
{
    /// <summary>
    /// Interface IAggregateRoot
    /// </summary>
    public interface IAggregateRoot
    {
    }
}
