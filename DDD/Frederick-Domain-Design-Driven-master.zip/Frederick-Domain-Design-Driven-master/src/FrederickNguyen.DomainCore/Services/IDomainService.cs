﻿// ***********************************************************************
// Assembly         : FrederickNguyen.DomainCore
// Author           : thangnd
// Created          : 07-19-2018
//
// Last Modified By : thangnd
// Last Modified On : 07-19-2018
// ***********************************************************************
// <copyright file="IDomainService.cs" company="FrederickNguyen.DomainCore">
//     Copyright (c) by adguard. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

namespace FrederickNguyen.DomainCore.Services
{
    /// <summary>
    /// Interface IDomainService
    /// </summary>
    public interface IDomainService
    {
    }
}
